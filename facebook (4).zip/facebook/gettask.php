<?php
require "config.php";
require "vendor/autoload.php";

require_once ('vendor/autoload.php');


session_start();


include "functions.php";


  $taskId = '5643';
 $resultarray = gettaskdetails( $taskId ); 
 print_r($taskId);
     
 
  
  print_r( $resultarray);
   
 //if only text

  
 //if only text

 if((isset($resultarray['video_img'])) && ($resultarray['video_img'] !=''))
 {  
     $fileextensionarray = explode('.', $resultarray['video_img']);


if ( (strcasecmp ( end($fileextensionarray) , 'mp4')) == 0)
{
 
   $videoData=[
	'description'=>$resultarray['content'],
	'source'=>$fb->videoToupload($resultarray['video_img']),
];
try
{
 $response=$fb->post('/me/videos',$videoData,$pageAccessToken);
 unlink($resultarray['video_img']);

}
catch(Facebook\Exceptions\FacebookResponseException $e)
{
echo 'Graph returned an error 55: '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
exit;
}
catch(Facebook\Exceptions\FacebookSDKException $e)
{
echo  'Facebook SDK returned an Error: '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
 
exit;
}
$graphNode = $response->getGraphNode();
echo 'ID:'.$graphNode['id'];
     updatetaskstage( $taskId);
     exit;
}
else

{


function resize($image_id,$width,$height) 
{
$new_width =1920;
$new_height =1080;
$layer=imagecreatetruecolor($new_width,$new_height);
imagecopyresampled($layer,$image_id,0,0,0,0,$new_width,$new_height, $width,$height);
return $layer;
}


   $imageData=[
	
	'source'=>$fb->fileToupload($resultarray['video_img']),
	'message'=>$resultarray['content'],
];

$file = $resultarray['video_img']; 
  $image_prop = getimagesize($file);
  $image_type = $image_prop[2]; 
  if( $image_type == IMAGETYPE_JPEG ) 
    {   
    $image_resource_id = imagecreatefromjpeg($file);  
    $layer = resize($image_resource_id,$image_prop[0],$image_prop[1]);
    imagejpeg($layer,$resultarray['video_img'] . "_thump.jpg");
     //unlink($resultarray['video_img']);
     $resultarray['video_img']=$resultarray['video_img']. "_thump.jpg";

     //print_r($resultarray['video_img']);
    }
  else if( $image_type == IMAGETYPE_GIF )  
    {  
    $image_id = imagecreatefromgif($file);
    $layer = resize($image_id,$image_prop[0],$image_prop[1]);
    imagegif($layer,$resultarray['video_img']. "_thump.gif");
     //unlink($resultarray['video_img']);
     $resultarray['video_img']=$resultarray['video_img']. "_thump.gif";
    }
  else if( $image_type == IMAGETYPE_PNG )
    {
    $image_id = imagecreatefrompng($file); 
    $layer = resize($image_id,$image_prop[0],$image_prop[1]);
    imagepng($layer,$resultarray['video_img'] . "_thump.png");
     //unlink($resultarray['video_img']);
     $resultarray['video_img']=$resultarray['video_img']. "_thump.png";
    }
  



try
{
 $response=$fb->post('/me/photos',$imageData,$pageAccessToken);
 //unlink($resultarray['video_img']);


}
catch(Facebook\Exceptions\FacebookResponseException $e)
{
echo 'Graph returned an error 55: '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
exit;
}
catch(Facebook\Exceptions\FacebookSDKException $e)
{
echo  'Facebook SDK returned an Error: '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
 
exit;
}
$graphNode = $response->getGraphNode();
echo 'ID:'.$graphNode['id'];
     updatetaskstage( $taskId);
     exit;
}
}
   
else{
 if((isset($resultarray['link'])) && ($resultarray['link'] !=''))
 {
 $data=[
 	
	'link'=>$resultarray['link'],
	'message'=>$resultarray['content'],
];
try
{
	$response=$fb->post('/me/feed',$data,$pageAccessToken);

}

catch(Facebook\Exceptions\FacebookResponseException $e)
{
 
      updatecomment( $taskId,$e->getMessage());
echo 'Graph returned an error  : '.$e->getMessage();
exit;
}
catch(Facebook\Exceptions\FacebookSDKException $e)
{
 
echo 'Facebook SDK returned an Error: '.$e->getMessage();
exit;
}
$graphNode = $response->getGraphNode();
echo 'ID:'.$graphNode['id'];
updatetaskstage( $taskId);
}
else
 
try
{
	 
	$response = $fb->post('/me/feed',[
	'message'=>$resultarray['content'],
    ],$pageAccessToken);
}

catch(Facebook\Exceptions\FacebookResponseException $e)
{
      
echo 'Graph returned an error : '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
exit;
}
catch(Facebook\Exceptions\FacebookSDKException $e)
{
      
echo 'Facebook SDK returned an Error: '.$e->getMessage();
 updatecomment( $taskId,$e->getMessage());
exit;
}
$graphNode = $response->getGraphNode();
echo 'ID:'.$graphNode['id'];
updatetaskstage( $taskId);
}
?>