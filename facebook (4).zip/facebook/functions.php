<?php
 //fetches content, url and image file
 function gettaskdetails($taskId)
 {  
 $responsee = file_get_contents('https://thinkventures.bitrix24.com/rest/3/nwnd8amyrgo152a7/task.item.getdata?taskId='.$taskId);
    
$response = json_decode($responsee);

$resultarray = array();

  $res = json_decode($responsee); 
  $des = $res->result->DESCRIPTION; 
  $content =$des ;
  $resultarray['video_img']='';
 

  // if video is present
  if ((isset($res->result->UF_AUTO_796172523780))&&(  $res->result->UF_AUTO_796172523780  !='') )
  {
     $resultarray['video_img'] =  $res->result->UF_AUTO_796172523780 ; 
  }

  //print_r('1' . $content);
  // if image is there seperate content from image
  if (strpos($des, '[IMG') !== false) {
    $content = substr($des, 0, strpos($des, "[IMG")); 
    $imgurl = substr($des, strpos($des, "[IMG"), strpos($des, "[/IMG]")); 
   
      $kk = str_replace('[','<',$imgurl) ;
      $km = str_replace(']','>',$kk) ;
      $mm=strip_tags($km);
       $resultarray['video_img'] =   $mm ; 
 
}
//print_r($content);
//get imag/videio if attached
 
  //print_r('1' . $content);
  // if image is there seperate content from image
  if (strpos($des, '[URL') !== false) {
   
$linkedinn =1;
     if($linkedinn ==1)
     {  
      $content2 = substr($content, 0, strpos($content, "[URL")); 
          $linkurl = substr($des, strpos($des, "[URL")   ); 
            $linkurl1 = substr( $linkurl , 5 ,  strpos(   $linkurl, ']')-5   ); 
 
    
        $kk = str_replace('[','<',$linkurl) ;
        $km = str_replace(']','>',$kk) ;
      
        $mm=strip_tags($km);
        
       //  $resultarray['video_img'] =   $mm ; 
      //$resultarray['link'] =   $mm ; 
       $resultarray['link'] =$linkurl1;
       
       //mitanshi : 
         if (strpos($content, '<p') !== false)
            $content = preg_replace_callback('!(<p[^>]*>)(.*?)</p>!is', 'clean_pre', $content );
    $content = preg_replace( "|\n</p>$|", '</p>', $content );
 
        
        
      $content =     $content2;
      print_r('this is content line 59 ' . $content);
       print_r($resultarray);
     }
     else
     {

      $content = substr($des, 0, strpos($des, "[URL")); 
  
      $linkurl = substr($des, strpos($des, "[URL"), strpos($des, "[URL"));  
     
        $kk = str_replace('[','<',$linkurl) ;
        $km = str_replace(']','>',$kk) ;
        $mm=strip_tags($km);
       //  $resultarray['video_img'] =   $mm ; 
      
       
       
       
      $content =     $content . $mm;
            print_r('this is content line 74 ' . $content);
     }
     
 
}

    if  (isset($res->result->UF_TASK_WEBDAV_FILES)) 
    {
 
      $imagearray = $res->result->UF_TASK_WEBDAV_FILES;
    //  print_r(  $imagearray);

     
      if (count($imagearray ) >0)
      {
        $fileid=  $imagearray[0]->FILE_ID  ;

        $filedesc = file_get_contents('https://thinkventures.bitrix24.com/rest/3/nwnd8amyrgo152a7/disk.file.get?id='.$fileid);
        $filedescresp= json_decode($filedesc);
        $fname = $filedescresp->result->NAME; 
        $downloadurl= $filedescresp->result->DOWNLOAD_URL; 
        //$resultarray['img'] = $filepath; 
        $filepath =getfile( $fname ,$downloadurl);
       // print_r(  $filepath);
        $resultarray['video_img'] =  $filepath ; 
        if(!(isset(  $resultarray['link'])))
        {
          $resultarray['link'] = $filepath;
        }

      }
       
    }
  
//print_r('2' . $content);

//// if video is there seperate content from vidoe url
if (strpos($content, '[DISK') !== false) {
  $contents = substr($content, 0, strpos($content, "[DISK")); 
 //print_r( $contents);
 $content =  $contents ;
}

 //this is the contented to be posted on linkedin
$resultarray['content'] =   $content ;

 return ($resultarray);
 }
 
 // move to next stage if successfully posted
 function updatetaskstage( $taskid)
{
   
    $queryurl2 = "https://thinkventures.bitrix24.com/rest/3/nwnd8amyrgo152a7/tasks.task.update";
 

 
  $querydata2 = http_build_query(array( 
  'taskId' => $taskid,
   'fields'=> array('STAGE_ID'=> 567  ))); 
  $res = curlCall($queryurl2  ,  $querydata2);
  print_r($res);

}

 function  updatecomment( $taskid,$error)
 {  
 
 
 
 if(  isset( $error->message))
 {
    $queryurl2 = "https://thinkventures.bitrix24.com/rest/3/nwnd8amyrgo152a7/task.commentitem.add";
 
  $querydata2 = http_build_query(array( 
 $taskid, array("POST_MESSAGE" => $error->message)))  ;
    
  $res = curlCall($queryurl2  ,  $querydata2);
  print_r($res);
  
 }
 else
 {    
      $queryurl2 = "https://thinkventures.bitrix24.com/rest/3/nwnd8amyrgo152a7/task.commentitem.add";
 
  $querydata2 = http_build_query(array( 
 $taskid, array("POST_MESSAGE" => $error )))  ;
    
  $res = curlCall($queryurl2  ,  $querydata2);
  print_r($res);
   
     
 }
   
    
  } 
 
  function curlCall($queryUrl, $querydata)
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_SSL_VERIFYPEER => 0,

        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => $queryUrl,
        CURLOPT_POSTFIELDS => $querydata,
    ));

    $result = curl_exec($curl);

    $data = json_decode($result, true);
    return ($data);

}

  // gets document from bitrix and create  a temp file
function writeToLog($data, $type)
{
    $log = "\n------------------------\n";
    $log .= date("Y.m.d G:i:s") . "\n";
 
    $log .= print_r($data, 1);
    $log .= "\n------------------------\n";
  
  $fname = "default.log";
  if($type=='linkedin')
  {
      
  $fname = "linkedin.log";
  }
    if ((file_exists($fname)) && (filesize($fname) > 1000000))
    {
        unlink($fname);

    }
    file_put_contents(getcwd() . '/' .$fname , $log, FILE_APPEND);
    return true;

}
  
   function getfile($file_name,$downloadurl)
  {
 
// Use file_get_contents() function to get the file 
// from url and use file_put_contents() function to 
// save the file by using base name 
$content = '';

//EXPLODEFILENAME_ADD TIME STAMP TO AVOID DUPLICATE

$filenamearray =  explode(".", $file_name) ;
print_r($filenamearray);
$fname = $filenamearray[0] . time();
$extension =  $filenamearray[1];

$file_name = $fname . '.' . $extension; 
if(file_put_contents( $file_name,file_get_contents($downloadurl))) { 
  //  echo "File downloaded successfully"; 
} 
else { 
   // echo "File downloading failed."; 
} 
 
//return   'https://tdu.sqy.mybluehost.me/socialmedia/' . $file_name  ;
return $file_name;
 
  }
   