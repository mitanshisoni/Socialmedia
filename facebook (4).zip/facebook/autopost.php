<?php
require "vendor/autoload.php";

require_once ('vendor/autoload.php');

$access_token = "EAAG146e9pH8BAGrsPJ5qKTq2gF5339fglcJ8l3dKwOZBkStHhXxZBDVOHnnhinSKpWmDjfAba6ieqLi9HXZCd0UE5TmkxvgBs55TVydETfnlmG8bNvpcbFuHR0ORCc8NdgeJU8mQSGJCCojS7xrIZBeLBvmL7xxSE1g2miUBZBAZDZD";
$facebookData = array();
$facebookData['consumer_key'] = "481464353137791";
$facebookData['consumer_secret'] = "94f109d1125646a99db8a4539c8e0234";
 
$title = "Testing";
$targetUrl = "www.google.com";
$imgUrl = "";
$description = "POSTING"; 
 
$facebook = new FacebookApi($facebookData);
$facebook->share($title, $targetUrl, $imgUrl, $description, $access_token);
require_once("facebook-php-sdk-master\src\facebook.php");
class FacebookApi 
{
  
 var $consumer;
 var $token;
 var $method;
 var $http_status;
 var $last_api_call;
 var $callback;
 var $connection;
 var $access_token;
 
 function __construct($data)
 {
  $config = array();
  $config['appId'] = $data['consumer_key'];
  $config['secret'] = $data['consumer_secret'];
 
  $this->connection = new Facebook($config);
 
 }
 
 function share($title, $targetUrl, $imgUrl, $description, $access_token)
 {
  $this->connection->setAccessToken($access_token);
  $params["access_token"] = $access_token;
  
  if(!empty($title))
  {
   $params["message"] = $title;
   $params["name"] = $title;
  }
  
  if(!empty($targetUrl))
  {
   $params["link"] = $targetUrl;
  }
  
  if(!empty($imgUrl))
  {
   $params["picture"] = $imgUrl;
  }
  
  if(!empty($description))
  {
   $params["description"] = $description;
  }
 
  // post to Facebook
  try 
  {
   $ret = $this->connection->api('/me/feed', 'POST', $params);
  }
  catch(Exception $e) 
  {
   $e->getMessage();
  }
 
  return true;
 }
 
 function getLoginUrl($params)
 {
  return $this->connection->getLoginUrl($params);
 }
 
 function getContent($url) 
 {
  $ci = curl_init();
  /* Curl settings */
  curl_setopt($ci, CURLOPT_URL, $url);
  curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ci, CURLOPT_HEADER, false);
  curl_setopt( $ci, CURLOPT_CONNECTTIMEOUT, 10 );
  curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
 
  $response = curl_exec($ci);
  curl_close ($ci);
  return $response;
 }
 
}
?>