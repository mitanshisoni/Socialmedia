<?php
require "vendor/autoload.php";

require_once ('vendor/autoload.php');




$fb = new Facebook\Facebook([    

'app_id' => '206743911040156',


'app_secret' => '498d91c4cb1ceb0593c1a3b02aff4366',


'default_graph_version' => 'v2.3',


]);

$pageAccessToken = "EAAC8CFFghJwBANp3hWB0jwuYY37ZAcAbGiUn8QJeyf4bJXg7C5uqfgRpzAjuTQq0nRNpFPbDKuY20ZBDBKZBzlZCm6A7kzAkrMj50YJr1NnEHHnyQq0c8Fbag1oRcYFOfg5Hllxu28u2FpPpvQhi1NKb9mjkQxzwJzLp5IRmnN8epZBMbOrch";
?>